<?php
$connect=mysqli_connect('localhost','root','','resultdb');
if(mysqli_connect_errno($connect))
{
echo "failed to connect";
}

?>
